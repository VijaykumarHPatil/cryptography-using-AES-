## File Encryption and Decryption Using AES Algorithm
### Introduction:
  This project is all about the Data Security. How we can secure our data from hackers. The symmetric-key block cipher plays an important role in data encryption. It means that the same key is used for both encryption and decryption. The Advanced Encryption Standard (AES) is a widely used symmetric-key encryption algorithm. In this project, we’ll see how to implement AES encryption and decryption using the Python on the any kind of files using pycryptodomex package. 
 
### Aim and Objective: 
   As we know that today hackers are almost at every corner in search of our useful data which can be hacked by them for their different purposes. Even the risk gets doubled when come to the data of any country’s government. So, a system or terminology is must require to make that data safe forever by any means during communication. So the main aim of the project is to secure our important data from hackers and keep it safe. 1.2 Problem




